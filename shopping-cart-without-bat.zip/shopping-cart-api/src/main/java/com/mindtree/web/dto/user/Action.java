package com.mindtree.web.dto.user;

public enum Action {
    ADD, UPDATE;
}

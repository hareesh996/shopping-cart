package com.midtree.core.sql;

public enum SortOrder {
    ASC,DESC;
}

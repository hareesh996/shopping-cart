package com.mindtree.web.configurations;

import org.springframework.context.annotation.Profile;

@Profile("cloud")
public class CloudConfigurations {


}

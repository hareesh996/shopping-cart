package com.mindtree.core.exception;

public class HttpErrorException extends RuntimeException{
}

package com.mindtree.dao;

import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public class AbstractRepository {



}

insert into product(product_id, created_date, modified_date, price, product_name)
values (1,current_timestamp, null, 450, 'COVID19 or Wuhan Virus');
insert into book(author, genre, publications, product_id)
values ('John Stell', 'Reality', 'ANC Publications', 1);


insert into product(product_id, created_date, modified_date, price, product_name)
values (2,current_timestamp, null, 4500, 'Nike QT Running');
insert into apparel(brand, design, type, product_id )
values('Nike', 'Air', 'Running', 2);
